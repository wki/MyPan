package Another::Module::Xxx;
our $VERSION = '2.02';

1;
