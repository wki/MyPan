package Another::Module;
our $VERSION = '0.03';

1;
