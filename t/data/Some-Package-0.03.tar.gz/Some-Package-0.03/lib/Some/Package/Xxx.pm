package Some::Package::Xxx;
our $VERSION = '0.02';

1;
